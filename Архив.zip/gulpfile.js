'use strict'

const gulp        = require('gulp'),
      plugins     = require('gulp-load-plugins')(),
      browserSync = require('browser-sync'),
      reload      = browserSync.reload,
      shell       = require('gulp-shell')

let path = require('./gulptask/path')

function getTask (task, paths) {
  return require('./gulptask/' + task)(gulp, plugins, paths)
}

gulp.task('connect', function () {
  browserSync.init({
    proxy : 'news.loc',
    port  : 4000,
    open  : false,
    notify: false
  })
})

gulp.task('reload', function () {
  browserSync.reload()
})

gulp.task('sass:full', getTask('sass', {src: path.src.css, dest: path.dest.css, compress: false}))

gulp.task('sass:min', getTask('sass', {
  src     : path.src.css,
  dest    : path.dest.css,
  compress: true
}))

gulp.task('dump', shell.task([
  'touch ' + path.mysql.db + '.sql',
  'mysqldump -u ' + path.mysql.user + ' -p' + path.mysql.pass + ' ' + path.mysql.db + ' > ' + path.mysql.db + '.sql'
]))

gulp.task('sass', ['sass:min', 'sass:full'])

gulp.task('watch', function () {
  gulp.watch(path.watch.css, ['sass', 'reload'])
  browserSync.watch('**/*.php').on('change', reload)
})

gulp.task('default', ['connect', 'watch'])

