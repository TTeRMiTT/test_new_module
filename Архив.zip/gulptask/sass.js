module.exports = function (gulp, plugins, paths) {
  let name = 'site.css' , outputStyle = 'nested';
  if (paths.compress){
    name = 'site.min.css' ;
    outputStyle = 'compressed';
  }
  return function () {
    gulp.src(paths.src)
      .pipe(plugins.plumber({
         // errorHandler: notify.onError('SASS error: <%= error.message %>')
      }))
      .pipe(plugins.sourcemaps.init())
      .pipe(plugins.sass({
        outputStyle: outputStyle
      }))
      .pipe(plugins.autoprefixer({
        browsers: ['last 10 versions']
      }))
      .pipe(plugins.rename(name))
      // .pipe(plugins.cleanCss())
      .pipe(plugins.sourcemaps.write())
      .pipe(plugins.plumber.stop())
      .pipe(gulp.dest(paths.dest))
  }
}