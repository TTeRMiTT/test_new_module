module.exports = {
  dest : {
    css: 'public_html/css/'
  },
  src  : {
    css: 'src/scss/**/style.scss'
  },
  watch: {
    css: 'src/scss/**/*.*',
  },
  mysql : {
    db: 'test.loc',
    path: 'localhost',
    user: 'root',
    pass: 'root'
  }
}