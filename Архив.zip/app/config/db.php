<?php
return [
  'db' => [
    'type' => 'mysqli',
    'host' => 'localhost',
    'dbname' => 'test.loc',
    'charset' => 'utf8',
    'user' => 'root',
    'pass' => 'root'
  ]
];