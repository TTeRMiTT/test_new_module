<?php
return [
  'component' => [
    'language' => 'ru',
    'charset'  => 'utf-8',
  ],
];