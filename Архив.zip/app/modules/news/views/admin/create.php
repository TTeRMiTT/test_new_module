<?php
$this->title = 'Создание новости';
?>
<div class="menu-create">

    <?= $this->render('_form', ['model' => $model])?>

</div>