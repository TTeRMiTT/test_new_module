<?php
$this->title = 'Редактирование новости';

?>
<div class="menu-update">

    <?= $this->render('_form', ['model' => $model])?>

</div>