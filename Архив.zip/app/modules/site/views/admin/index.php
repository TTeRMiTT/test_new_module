<?php
$this->title = 'Главная | Admin';
?>
<h1>Главная | Admin</h1>