<?php

$this->title = 'О нас';
?>
<h1><?=$this->title?></h1>
