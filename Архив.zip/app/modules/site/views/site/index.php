<?php
$this->title = 'Главная';
?>
<h1><?=$this->title?></h1>

