<?php
namespace app\core;


use app\App;

class Uri
{

    public static function to($url)
    {
    }
}