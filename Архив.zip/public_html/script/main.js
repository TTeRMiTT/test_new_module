tinymce.init({
  selector: 'textarea',
  language_url : '/script/tinymce/langs/ru.js',
  language: 'ru'
});

